import sys
import codecs

fp = codecs.open(sys.argv[1],'r','utf-8')
fps = codecs.open('devanagari_positive_subjective.txt','w','utf-8')
fns = codecs.open('devanagari_negative_subjective.txt','w','utf-8')
fs = codecs.open('devanagari_subjective.txt','w','utf-8')

for l in fp:
	wl = l.split()
	word = wl[0].strip(' \t\n\r')
	pos = float(wl[1].strip(' \t\n\r')) + 4.0 - 4.0
	neg = float(wl[2].strip(' \t\n\r')) + 4.0 - 4.0
	obj = float(wl[3].strip(' \t\n\r')) + 4.0 - 4.0
	if obj <= 0.4:
		fs.write(word)
		fs.write('\n')
	if pos > 0.5:
		fps.write(word)
		fps.write('\n')
	if neg > 0.5:
		fns.write(word)
		fns.write('\n')
fp.close()
fps.close()
fns.close()
fs.close()
