################################################## Communal tweet classifier ####################################################
How to run: python communal_classifier.py <input file>
Sample run: python communal_classifier.py nepal_communal_train.txt

################################################## Communal future classifier ###################################################
How to run: python communal_future_classifier.py <input file> <pos tagged file> <output file>
Inputs: 1. Input file format: Date \t Tweet ID \t Screen name \t Tweet \t Original user screen name (if it is a retweet) \t screen name of users mentioned in this tweet \t follower count of user
	2. Pos tagged output of tweets

Output: Input file + '\t' + class of tweet (1 = communal/ 2 = non-communal)

Sample input file: kashmir_input.txt
Sample output file: kashmir_communal_predicted.txt

################################################## Anti-communal tweet classifier ################################################
How to run: python anti_communal_classifier.py <input file>
Input file: Tweet \t class
Sample run: python anti_communal_classifier.py nepal_anti_communal_train.txt

################################################## Anti-communal future classifier ###############################################
How to run: python anti_communal_future_classifier.py <input file> <pos tagged file> <output file>
Inputs: 1. Input file format: Date \t Tweet ID \t Screen name \t Tweet \t Original user screen name (if it is a retweet) \t screen name of users mentioned in this tweet \t follower count of user \t class label (1/2)
	2. Pos tagged output of tweets

Output: Input file + '\t' + class of tweet (1 = communal/ 2 = non-communal/ 3 = anti-communal)

Sample input file: kashmir_communal_predicted.txt
