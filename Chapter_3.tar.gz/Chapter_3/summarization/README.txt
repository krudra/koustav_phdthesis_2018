############################################# Directory : situational_tweets #########################################
It contains machine classified tweets which are tagged as situational with confidence score >= 0.8. Note that, this dataset contains only situtaional tweets. Here, we provide a sample file from
Hyderabad blast.

############################################# Directory : data extraction #############################################
content_word_extraction.py extracts all the content words from the situational tweets.
How to run: python content_word_extraction.py ../situational_tweets/hydb_SITUATIONAL.txt ../../Lexical_resources/location_dictionary/hydb_place.txt hydb_CONTENT.txt
In this phase we extract basic content words (Numerals, Nouns, Verbs, Places).

Rest of the preprocessing phases are handled here --- 
	1. Case folding
	2. Lemmatization
	3. Uniformity in numeral representation

############################################# Directory : ILP summarization ###########################################
NCOWTS.py takes content files from data extraction folder and produces the summary.
How to run: python NCOWTS.py ../data_extraction/hydb_CONTENT.txt hydb_breakpoint.txt  ../../Lexical_resources/location_dictionary/hydb_place.txt hydb
Inputs:
	1. hydb_CONTENT.txt => Contains details about tweets, content words present in tweets, length etc.
	2. hydb_breakpoint.txt => Contains two breakpoints at which the system should produce summaries
	3. hydb_place.txt => Contains location information of Hyderabad
	4. hydb => It is a keyword used to provide names to output files

NOTE: Paths need to be adjusted if default setup is changed
