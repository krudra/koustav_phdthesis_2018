python extract_terms.py ../classification/hydb_TWEB_SITUATIONAL.txt hydb_place.txt hydb_TWEB_CONCEPT.txt
python extract_terms.py ../classification/utkd_TWEB_SITUATIONAL.txt utkd_place.txt utkd_TWEB_CONCEPT.txt
python extract_terms.py ../classification/sandy_hook_TWEB_SITUATIONAL.txt sandy_hook_place.txt sandy_hook_TWEB_CONCEPT.txt
python extract_terms.py ../classification/hagupit_TWEB_SITUATIONAL.txt hagupit_place.txt hagupit_TWEB_CONCEPT.txt
python extract_terms.py ../classification/nepal_TWEB_SITUATIONAL.txt nepal_place.txt nepal_TWEB_CONCEPT.txt
python extract_terms.py ../classification/harda_TWEB_SITUATIONAL.txt harda_place.txt harda_TWEB_CONCEPT.txt
