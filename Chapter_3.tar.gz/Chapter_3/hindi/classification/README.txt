############################################### Check Accuracy of the Classifier ################################################

How to run: python DV_TAG_classifier.py nepal_devanagari_train.txt nepal_devanagari_postag.txt harda_devanagari_train.txt harda_devanagari_postag.txt

################################################### Run future classifier ########################################################

Python DV_TAG_Future_classifier.py <input file> <pos tag of input file> <output file>

python DV_TAG_Future_classifier.py harda_dataset.txt harda_postag_dataset.txt harda_predicted_dataset.txt

Input files should be in the following format: Date \t Tweet ID \t User ID \t Tweet
