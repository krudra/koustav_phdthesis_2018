import sys
import codecs


fp = codecs.open(sys.argv[1],'r','utf-8')
fo = codecs.open(sys.argv[2],'w','utf-8')

for l in fp:
	wl = l.split('\t')
	s = wl[0].strip(' \t\n\r') + '\t' + wl[1].strip(' \t\n\r') + '\t' + wl[2].strip(' \t\n\r') + '\t' + wl[3].strip(' \t\n\r')
	fo.write(s + '\n')
fp.close()
fo.close()
