'''
Created on 11-May-2015

@author: Koustav
'''

import sys
import re
import codecs
import string
import os
import numpy as np
from sklearn import svm
from sklearn.linear_model import *
from sklearn.naive_bayes import *
from sklearn import metrics
from sklearn.ensemble import *
from sklearn import cross_validation
import gzip
from sklearn.externals import joblib
#from happyfuntokenizing import *

mycompile = lambda pat:  re.compile(pat,  re.UNICODE)

PRONOUN_PATH = '../../../../Lexical_resources/devanagari/devanagari_personal_pronoun.txt'
WHWORD_PATH = '../../../../Lexical_resources/devanagari/devanagari_wh_words.txt'
SLANG_PATH = '../../../../Lexical_resources/devanagari/devanagari_slang.txt'
INTENSIFIER_PATH = '../../../../Lexical_resources/devanagari/devanagari_intensifier.txt'
SUBJECTIVE_PATH = '../../../../Lexical_resources/devanagari/devanagari_subjective.txt'
EVENT_PATH = '../../../../Lexical_resources/devanagari/devanagari_domain_list.txt'
RELIGION_PATH = '../../../../Lexical_resources/devanagari/devanagari_religion.txt'
MODAL_VERB_PATH = '../../../../Lexical_resources/devanagari/devanagari_modal_verb.txt'

PRONOUN = {}
INTENSIFIER = {}
WHWORD = {}
SLANG = {}
EVENT = {}
MODAL = {}
RELIGION = {}
SUBJECTIVE = {}

emoticon_string = r"""
    (?:
      [<>]?
      [:;=8]                     # eyes
      [\-o\*\']?                 # optional nose
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth      
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\] # mouth
      [\-o\*\']?                 # optional nose
      [:;=8]                     # eyes
      [<>]?
    )"""

#TAGGER_PATH = '/home/krudra/twitter_code/term_project/ark-tweet-nlp-0.3.2/'

def getNumberofHashTags(s):
    return len(re.findall(r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""", s))

def getNumberOfCaps(s):
    return len(re.findall("[A-Z]+", s))

def getNumberOfPunctuations(s):
    punctuations= string.punctuation
    punctuations = re.sub("[#@]", "", punctuations)
    #print punctuations
    return len(re.findall("['%s']"%punctuations, s))

#def getNumberOfSmileys(s):
#    return len(re.findall(emoticon_string, s))

def getNumberOfPositiveSmileys(s):
    NormalEyes = r'[:=]'
    #Wink = r'[;]'
    NoseArea = r'(|o|O|-)'   ## rather tight precision, \S might be reasonable...
    HappyMouths = r'[D\)\]]'
    #SadMouths = r'[\(\[]'
    #Tongue = r'[pP]'
    #OtherMouths = r'[doO/\\]'  # remove forward slash if http://'s aren't cleaned
    Happy_RE =  mycompile( '(\^_\^|' + NormalEyes + NoseArea + HappyMouths + ')')
    #Sad_RE = mycompile(NormalEyes + NoseArea + SadMouths)
    
#     Wink_RE = mycompile(Wink + NoseArea + HappyMouths)
#     Tongue_RE = mycompile(NormalEyes + NoseArea + Tongue)
#     Other_RE = mycompile( '('+NormalEyes+'|'+Wink+')'  + NoseArea + OtherMouths )
#     
#     Emoticon = (
#         "("+NormalEyes+"|"+Wink+")" +
#         NoseArea + 
#         "("+Tongue+"|"+OtherMouths+"|"+SadMouths+"|"+HappyMouths+")"
#     )
#     Emoticon_RE = mycompile(Emoticon)
# 
#     Emoticon_RE = "|".join([Happy_RE,Sad_RE,Wink_RE,Tongue_RE,Other_RE])
#     Emoticon_RE = mycompile(Emoticon_RE)
    return len(re.findall(Happy_RE, s))    

def getNumberOfNegativeSmileys(s):
    NormalEyes = r'[:=]'
    NoseArea = r'(|o|O|-)'   ## rather tight precision, \S might be reasonable...
    SadMouths = r'[\(\[]'
    Sad_RE = mycompile(NormalEyes + NoseArea + SadMouths)
    return len(re.findall(Sad_RE, s))    

#print getNumberofHashTags("#unni_k #win AB")
#print getNumberOfCaps("#unni_k #win AB CC")
#print getNumberOfPunctuations("!!?")
#print getNumberOfSmileys(":):P")
#print getNumberOfElongatedWords("sooo muchhhhh")
#print getNumberOfPositiveSmileys(":) :( :P :-) :D :P")
#print getNumberOfNegativeSmileys(":( :) :(")

def isLastCharacterPunctuation(s):
    if(s[-1]=='!' or s[-1]=='?'):
        return 1
    return 0

def isLastTokenPositiveEmoticon(s):
    lastToken = s.split()[-1]
    if(getNumberOfPositiveSmileys(lastToken)>=1):
        return 1
    return 0

def isLastTokenNegativeEmoticon(s):
    lastToken = s.split()[-1]
    if(getNumberOfNegativeSmileys(lastToken)>=1):
        return 1
    return 0        

def getNumberOfPositiveWords(s):
    with open("positiveWords.txt", "r") as f:
        wordsFromS = set(s.split())
        wordsFromFile = set(x.rstrip() for x in f.readlines())
        #print wordsFromS
        return len(wordsFromFile.intersection(wordsFromS))

def getNumberOfNegativeWords(s):
    with open("negativeWords.txt", "r") as f:
        wordsFromS = set(s.split())
        wordsFromFile = set(x.rstrip() for x in f.readlines())
        #print wordsFromS
        return len(wordsFromFile.intersection(wordsFromS))

def READ_FILES():

        fp = codecs.open(PRONOUN_PATH,'r','utf-8')
        for l in fp:
                PRONOUN[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(INTENSIFIER_PATH,'r','utf-8')
        for l in fp:
                INTENSIFIER[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(WHWORD_PATH,'r','utf-8')
        for l in fp:
                WHWORD[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(SLANG_PATH,'r','utf-8')
        for l in fp:
                SLANG[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(EVENT_PATH,'r','utf-8')
        for l in fp:
                EVENT[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(MODAL_VERB_PATH,'r','utf-8')
        for l in fp:
                MODAL[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(RELIGION_PATH,'r','utf-8')
        for l in fp:
                RELIGION[l.strip(' \t\n\r')] = 1
        fp.close()

        fp = codecs.open(SUBJECTIVE_PATH,'r','utf-8')
        for l in fp:
		SUBJECTIVE[l.strip(' \t\n\r')] = 1
        fp.close()


#getNumberOfNegativeWords("aa b")    

############################ This Functions are used #############################################
def emoticons(s):
        return len(re.findall(u'[\U0001f600-\U0001f60f\U0001f617-\U0001f61d\U0001f632\U0001f633\U0001f638-\U0001f63e\U0001f642\U0001f646-\U0001f64f\U0001f612\U0001f613\U0001f615\U0001f616\U0001f61e-\U0001f629\U0001f62c\U0001f62d\U0001f630\U0001f631\U0001f636\U0001f637\U0001f63c\U0001f63f-\U0001f641\U0001f64d]', s))

def smileys(s):
        return len(re.findall(r':\-\)|:[\)\]\}]|:[dDpP]|:3|:c\)|:>|=\]|8\)|=\)|:\^\)|:\-D|[xX8]\-?D|=\-?D|=\-?3|B\^D|:\'\-?\)|>:\[|:\-?\(|:\-?c|:\-?<|:\-?\[|:\{|;\(|:\-\|\||:@|>:\(|:\'\-?\(|D:<?|D[8;=X]|v.v|D\-\':|>:[\/]|:\-[./]|:[\/LS]|=[\/L]|>.<|:\$|>:\-?\)|>;\)|\}:\-?\)|3:\-?\)|\(>_<\)>?|^_?^;|\(#\^.\^#\)|[Oo]_[Oo]|:\-?o',s))

def getNumberOfElongatedWords(s):
    return len(re.findall('([a-zA-Z])\\1{2,}', s))
    
def pronoun(sen):

	for x in sen:
                if PRONOUN.__contains__(x)==True:
                        return 1
        return 0

def exclamation(s):
	c = len(re.findall(r"[!]", s))
	if c>=1:
		return 1
	return 0

def question(s):
	return len(re.findall(r"[?]", s))

def intensifier(sen):
	count = 0
        for x in sen:
                if INTENSIFIER.__contains__(x)==True:
                        count+=1
                        #return 1
        if count>0:
                return 1
        return 0

def religion(sen):

        for x in sen:
                if RELIGION.__contains__(x)==True:
                        return 1
        return 0

def whword(sen):

	for x in sen:
                if WHWORD.__contains__(x)==True:
                        return 1
        return 0

def slang(sen):

	for x in sen:
                if SLANG.__contains__(x)==True:
                        return 1
        return 0

def event_phrase(sen):
	
	for x in sen:
                if EVENT.__contains__(x)==True:
                        return 1
        return 0

def getHashtagopinion(sen):
	fp = codecs.open(OPINION_HASHTAG_PATH,'r','utf-8')
	temp = set([])
	for l in fp:
		temp.add(l.strip(' \t\n\r').lower())
	fp.close()

	cur_hash = set([])
	for x in sen:
		if x.startswith('#')==True:
			cur_hash.add(x.strip(' \t\n\r').lower())
	size = len(temp.intersection(cur_hash))
	if size>0:
		return 1
	return 0

def numeral(temp):
	c = 0
	for x in temp:
		if x.isdigit()==True:
			c+=1
	return c

def getNewsMention(sen):
	fp = codecs.open(MENTION_PATH,'r','utf-8')
	temp = set([])
	for l in fp:
		temp.add(l.strip(' \t\n\r').lower())
	fp.close()

	cur_men = set([])
	for x in sen:
		if x.startswith('@')==True:
			cur_men.add(x.strip(' \t\n\r').lower())
	size = len(temp.intersection(cur_men))
	if size>0:
		return 1
	return 0
	
def modal(sen):

	for x in sen:
                if MODAL.__contains__(x)==True:
                        return 1
        return 0

def subjectivity(sen):
	c = 0
        for x in sen:
                if SUBJECTIVE.__contains__(x)==True:
                        c+=1
        tot = len(sen) + 4.0 - 4.0 - 1.0
        num = c + 4.0 - 4.0
        try:
                s = round(num/tot,4)
        except:
                s = 0
        if c>0:
                return c
        return 0

######################## Upto this part used #############################################################3

#HashTagSentimentUnigrams("Oh wrestle", "NRC-Hashtag-Sentiment-Lexicon-v0.1/unigrams-pmilexicon.txt")
#HashTagSentimentUnigrams("Oh no wrestle", "Sentiment140-Lexicon-v0.1/unigrams-pmilexicon.txt")
#print negatedContextCount("this is not for me")
            
if __name__ == '__main__':

	READ_FILES()

	fs = codecs.open(sys.argv[2],'r','utf-8')
	fp = codecs.open(sys.argv[1],'r','utf-8')
	feature = []
	label = []
	count = 0
	temp = []
	N = 0
	#temp_raw = []
	for l in fs:
		wl = l.split('\t')
		if len(wl)>2:
			if wl[2].strip(' \t\n\r')!='SYM':
				temp.append(wl[0].strip(' \t\n\r'))
				if wl[2].strip(' \t\n\r')=='QC':
					N+=1
		else:
			if wl[0].strip(' \t\n\r')=='</s>':
				row = fp.readline().split('\t')
				bigram = []
				if len(temp)>1:
					for i in range(0,len(temp)-1,1):
						s = temp[i] + ' ' + temp[i+1]
						bigram.append(s)
				temp = temp + bigram
				#row = XL[3].strip(' \t\n\r')
				#temp = row[3].split()
				#N = numeral(temp)
				print(row[0].strip(' \t\n\r'))
				E = exclamation(row[3])
				Q = question(row[3])
				M = modal(temp)
				I = intensifier(temp)
				W = whword(temp)
				EP = event_phrase(temp)
				S = subjectivity(temp)
				SG = slang(temp)
				RL = religion(temp)
				P = pronoun(temp)
				#EM = emoticons(org_tweet[row[1].strip(' \t\n\r')])
				#SM = smileys(org_tweet[row[1].strip(' \t\n\r')])
				#t = [N,E,Q,M,I,W,S,P,EP,SG,EM,SM]
				t = [N,E,Q,M,I,W,S,P,EP,SG,RL]
				feature.append(t)
				label.append(int(row[4]))
				count+=1
				temp = []
				N = 0
			

	fp.close()
	fs.close()
	
	train_clf = joblib.load('SVCHINDIMODEL.pkl')
	predicted_label = train_clf.predict(feature)
	predicted_proba = train_clf.predict_proba(feature)
	
	fp = codecs.open(sys.argv[1],'r','utf-8')
	fo = codecs.open(sys.argv[3],'w','utf-8')
	
	index = 0
	for l in fp:
		wl = l.split('\t')
		s = ''
		for i in range(0,len(wl),1):
			s = s + wl[i].strip(' \t\n\r') + '\t'
		s = s + str(predicted_label[index]) + '\t' + str(max(predicted_proba[index]))
		fo.write(s + '\n')
		index+=1
	fp.close()
	fo.close()
