import sys
import os
import codecs
import re

dari = u'\u0964'
def split_tweet(ifname,ofname):
	fs = codecs.open(ifname,'r','utf-8')
	fp = codecs.open(ifname,'r','utf-8')
	fo = codecs.open(ofname,'w','utf-8')
	s = ''
	temp = []
	for l in fp:
		wl = l.split('\t')[3].strip(' \t\n\r').split()
		temp = []
		s = ''
		for x in wl:
			if x=='!' or x=='?' or x==dari:
				p = s.strip(' !?')
				q = p.strip(u'\u0964')
				s = q + x + ' '
				temp.append(s)
				s = ''
			else:
				YY = re.findall(u'([\u0964?!]+)',x)
				if len(YY)>0:
					p = s.strip(' !?')
					q = p.strip(u'\u0964')
					s = q + x + ' '
					#s = s + x + ' '
					temp.append(s)
					s = ''
				else:
					s = s + x + ' '
		if len(s.split())>0:
			t = s + dari
			temp.append(t)

		pl = fs.readline().split('\t')
		for x in temp:
			if len(x.split())>4:
				s = pl[0].strip(' \t\n\r') + '\t' + pl[1].strip(' \t\n\r') + '\t' + pl[2].strip(' \t\n\r') + '\t' + x.strip(' \t\n\r') + '\t' + pl[4].strip(' \t\n\r')
				fo.write(s)
				fo.write('\n')
	fp.close()
	fs.close()
	fo.close()

def main():
	try:
		_, ifname, ofname = sys.argv
	except Exception as e:
		print(e)
		sys.exit(0)
	split_tweet(ifname,ofname)
	print('Koustav Done')

if __name__=='__main__':
	main()
