import sys
import re
import codecs

dari = u'\u0964'
fp = codecs.open(sys.argv[1],'r','utf-8')
fo = codecs.open(sys.argv[2],'w','utf-8')
count = 0
for l in fp:
	tweet = l.split('\t')
	wl = tweet[3].strip(' \t\n\r').split()
	s = ''
	count+=1
	#print(tweet,len(tweet),count)
	for x in wl:
		#mini = re.findall(r"([\w#@-,]+)",x)
		if x.startswith('@')==False and x.startswith('#')==False:
			mini = re.findall(r"([0-9-,.:]+)",x)
			temp = re.findall(u'([\u0900-\u097F?!]+)',x)
        		url = re.findall(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+",x)
			#print(mini,temp,url)
			if len(url)==0:
				if len(temp)>0:
					for y in temp:
						s = s + y + ' '
						#fo.write(temp[0])
						#fo.write(' ')
				elif len(mini)>0:
					for y in mini:
						s = s + y + ' '
				else:
					pass
			#text = l.split('\t')[3].strip(' \t\n\r')
			'''text_1 = text.split()
			text_2 = text.split('#')
			text_3 = text_2.split('@')'''
			#print(text)
	s1 = s.strip()
	fo.write(tweet[0].strip(' \t\n\r'))
	fo.write('\t')
	fo.write(tweet[1].strip(' \t\n\r'))
	fo.write('\t')
	fo.write(tweet[2].strip(' \t\n\r'))
	fo.write('\t')
	fo.write(s1)
	last_char = s1[len(s1)-1]
	if last_char!='!' and last_char!='?' and last_char!=dari:
		fo.write(' ')
		fo.write(dari)
	fo.write('\t')
	fo.write('1')
	fo.write('\n')
	#print('complete')
	#break
#print(s1)
fp.close()
fo.close()
