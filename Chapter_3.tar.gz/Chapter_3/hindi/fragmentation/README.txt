######################################################### Remove English words ###############################
How to run: python filter_english.py <input> <output>

Sample: python filter_english.py harda_raw_data.txt harda_english_removed.txt

######################################################### Split tweets ########################################
How to run: python hindi_split.py <input>harda_english_removed.txt <output>harda_split_dataset.txt
