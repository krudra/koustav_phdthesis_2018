import sys
import codecs
import os



################################## nepal_EN_NOUN #################################################
'''Noun = {}
fp = codecs.open(sys.argv[1],'r','utf-8')
for l in fp:
	wl = l.split()
	Noun[wl[0].strip(' \t\n\r')] = 1
fp.close()

################################## nepal_EN_VERB #################################################
Verb = {}
fp = codecs.open(sys.argv[2],'r','utf-8')
for l in fp:
	wl = l.split()
	Verb[wl[0].strip(' \t\n\r')] = 1
fp.close()'''

STOPWORD = {}
fp = codecs.open('stopwords_hi.txt','r','utf-8')
for l in fp:
	STOPWORD[l.strip(' \t\n\r')] = 1
fp.close()

######################################### nepal place ############################################
Place = {}
fp = codecs.open(sys.argv[3],'r','utf-8')
for l in fp:
	Place[l.strip(' \t\n\r')] = 1
fp.close()

'''

argv[4] => nepal_situational_hindi_tkde.txt
argv[5] => nepal pos tag hindi
argv[6] => output file

'''

fs = codecs.open(sys.argv[1],'r','utf-8')
fp = codecs.open(sys.argv[2],'r','utf-8')
fo = codecs.open(sys.argv[4],'w','utf-8')

s = ''
z = ''
TAGREJECT = ['SYM']
count = 0
P = ''

for l in fp:
	wl = l.split()
	if len(wl)>2:
		word = wl[1].strip(' \t\n\r')
		tag = wl[2].strip(' \t\n\r')

		#P = P + wl[0].strip(' \t\n\r') + ' '
		if tag not in TAGREJECT:
			count+=1
		if Place.__contains__(word)==True:
			s = s + word + '_P '
			z = z + word + '_P '
		elif tag=='NN':
			#if Noun.__contains__(word)==True:
			s = s + word + '_CN '
			z = z + word + '_CN '
		elif tag=='NNP':
			#if Noun.__contains__(word)==True:
			s = s + word + '_PN '
			z = z + word + '_PN '
		elif tag=='VM':
			#if Verb.__contains__(word)==True:
			s = s + word + '_V '
			z = z + word + '_V '
		elif tag=='QC':
			s = s + word + '_S '
			z = z + word + '_S '
		#elif Place.__contains__(word)==True:
		#	s = s + word + '_P '
		#	z = z + word + '_P '
		elif tag not in TAGREJECT:
			#s = s + word + '_A '
			if STOPWORD.__contains__(word)==False and STOPWORD.__contains__(wl[0].strip(' \t\n\r'))==False:
				z = z + word + '_A '
	else:
		if wl[0].strip(' \t\n\r')=='</s>':
			temp = fs.readline().split('\t')
			#print(temp)
			E = temp[0].strip(' \t\n\r') + '\t' + temp[1].strip(' \t\n\r') + '\t' + temp[2].strip(' \t\n\r') + '\t' + temp[3].strip(' \t\n\r') + '\t' + s.strip() + '\t' + z.strip() + '\t' + str(count) + '\t' + str(temp[5].strip(' \t\n\r'))
			fo.write(E+'\n')
			count = 0
			#P = ''
			s = ''
			z = ''
		else:
			print('SKIP',wl[0].strip(' \t\n\r'))
fs.close()
fp.close()
fo.close()
