How to run
--------------------
python Tweet_Fragmenter.py

It takes all the files from Raw_Tweet folder and produces their pre-processed and fragmented version in Fragmented_Tweet folder.
Uniformity among numerals and lemmatization are particularly necessary for summarization step. We delegate these two tasks to summarization phase.
