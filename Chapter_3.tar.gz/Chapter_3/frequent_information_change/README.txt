Contains location specific updates based on key verbs

How to run: python Anomaly_Detection.py parsedfiles/hydb_parsed.txt ../Lexical_resources/location_dictionary/hydb_place.txt hydb_numeric_variation.txt

Note: Based on particular requirement like 'killed people', 'died people', 'stranded people', following lines (63 -- 66) in the code can be updated. For this particular case, no preprocessing, fragmentation or classification is required. We can parse the whole dataset and run this code.
