import sys
import os
import networkx as nx
from operator import itemgetter
from gurobipy import *
import math
import numbers
from textblob import *
import re
import time
from collections import Counter
import networkx as nx
import times
import codecs
from datetime import datetime
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import stopwords
import nltk
import itertools
import math
import aspell
import numpy as np
from numpy import linalg as LA

cachedStopWords = stopwords.words("english")
lmtzr = WordNetLemmatizer()
ASPELL = aspell.Speller('lang', 'en')

url = r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"

WORD = re.compile(r'\w+')
cachedstopwords = stopwords.words("english")
Tagger_Path = '../Lexical_Resources/ark-tweet-nlp-0.3.2/'
AUX = ['be','can','could','am','has','had','is','are','may','might','dare','do','did','have','must','need','ought','shall','should','will','would','shud','cud','don\'t','didn\'t','doesn\'t','no']

def summarize(parsefile,placefile,ofname):
	
	PLACE = {}
	fp = open(placefile,'r')
	for l in fp:
		if PLACE.__contains__(l.strip(' #\t\n\r').lower())==False:
			PLACE[l.strip(' \t\n\r').lower()] = 1
	fp.close()

	LIVING = {}
	fp = open('living.txt','r')
	for l in fp:
		LIVING[l.strip(' \t\n\r').lower()] = 1
	fp.close()
	
	TAGREJECT = ['#','@','~','U','E','G',',']


	''' Open the parse file '''

	fp = open(parsefile,'r')
	count = 0
	dic = {}
	place_dic = {}
	KILL = {}
	kill_list = ["kill", "kills", "killed", "dead", "die", "died", "dies"]
	'''die_list = ["dead", "die", "died", "dies"]
	inj_list = ["injure", "injured", "injures"]
	strand_list = ["strand", "stranded", "strands"]
	trap_list = ["trap", "trapped", "traps"]'''

	for l in fp:
		wl = l.split('\t')
                if len(wl)==8:
                        #print(wl[0])
                        seq = int(wl[0])
                        word = wl[1].strip(' #\t\n\r').lower()
                        tag = wl[4].strip(' \t\n\r')
                        dep = wl[6].strip(' \t\n\r')
                        if dep=='_':
                                dep = int(wl[7].strip(' \t\n\r'))
                        else:
                                dep = int(wl[6])
			
			if tag not in TAGREJECT:
				count+=1

                        temp = [word,tag,dep]
                        dic[seq] = temp
			if PLACE.__contains__(word)==True:
				place_dic[seq] = temp
                else:
                        temp = dic.keys()
                        temp.sort()
                        G = nx.Graph()
                        for x in temp:
                                G.add_node(x)
                        for x in temp:
                                dep = dic[x][2]
                                if dep!=-1 and dep!=0 and dic[x][1] not in TAGREJECT:
                                        G.add_edge(dep,x)
                        temp = sorted(nx.connected_components(G), key = len, reverse=True)
			CONTENT_WORDS = set([])
			PLACE_KEYS = place_dic.keys()
                        for i in range(0,len(temp),1):
                                comp = temp[i]
				VI = -1
				for x in comp:
					if dic[x][0] in kill_list:
						VI = x
						break
				if VI > 0:
					for x in comp:
						flag = 0
						if dic[x][1]=='$':
							P1 = re.findall(r'[^a-zA-Z0-9]+',dic[x][0])
							if len(P1)==0:
								flag = 1
						if dic[x][1]=='$' and flag==1:
							path = nx.shortest_path(G, source=x, target=VI)
							if len(path)<=3:
								assoc = ''
								if len(path)==3:
									if LIVING.__contains__(dic[path[1]][0])==True:
										assoc = dic[path[1]][0]
								if len(path)==2 or (len(path)==3 and len(assoc)>0):
									place_t = 'Default'
									for z in PLACE_KEYS:
										if z in comp:
											shp = []
											if z!=VI:
												shp.append(nx.shortest_path_length(G,source=z,target=VI))
											shp.sort()
											if len(shp)>0:
												if shp[0]<=2:
													place_t = dic[z][0]
													break
									if KILL.__contains__(place_t)==True:
										VK = KILL[place_t]
										tup = (dic[x][0],assoc)
										VK.append(tup)
										KILL[place_t] = VK
									else:
										VK = []
										tup = (dic[x][0],assoc)
										VK.append(tup)
										KILL[place_t] = VK
									
				
                        dic = {}
			place_dic = {}
			count = 0

	fp.close()

	fo = open(ofname,'w')
	for k,v in KILL.iteritems():
		fo.write(k + '\n')
		for x in v:
			fo.write(x[0].strip(' \t\n\r') + '\n')
	fo.close()
        
def main():
	try:
		_, parsefile, placefile, ofname = sys.argv
	except Exception as e:
		print(e)
		sys.exit(0)
	summarize(parsefile,placefile,ofname)

if __name__=='__main__':
	main()
