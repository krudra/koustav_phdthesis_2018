######################## Generating Features from a tweet file ###################################
python Generate_Features.py <input file> <output file>
input_file : one tweet per line
output_file : each line contains tab separated features for the corresponding tweet in the input file (line to line correspondence)

How to run : python Generate_Features.py sample_input.txt sample_output.txt

################################################ Get Classifier Accuracy ############################

How to run: python Classifier_Accuracy.py

############################################### Run classifier over future events ###################

How to run: python Future_classifier.py input_file output_file

Format of input_file: Each line should be in the following format (Date \t Tweet ID \t User ID \t Tweet)

############################################# Annotated Training data used to produce accuracies in Section 4.3 ########################################
Fragmented_train_data : It contains fragmented tweets with its labels used to train and test the classifier

label 1 => situational tweet and label 2 => Non-situational tweet
