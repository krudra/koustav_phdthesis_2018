################################################################# Concept extraction ##########################################################################
How to run: python extract_terms.py <input file> <place file> <output file>
Inputs:	1. input file format => Tweet ID \t Tweet \t Confidence score
	2. Place file contains information about locations
	3. output file contains concept details

Sample run: python extract_terms.py infrastructure_20150426.txt nepal_place.txt infrastructure_concept_20150426.txt

################################################################# Summarization ###############################################################################

################################################################# Extractive Step #############################################################################
How to run: python NCOWTS.py <input concept file> <place file> <keyword> <date> <word length>

Sample run: python NCOWTS.py infrastructure_concept_20150426.txt nepal_place.txt infrastructure 20150426 1000

It generates output file: infrastructure_ICOWTS_20150426.txt

################################################################## Path generation step ########################################################################
Step 1:
	python make_tagging.py <intermediate file (generate from extractive step)> <tagged file>
	Sample run: python make_tagging.py infrastructure_ICOWTS_20150426.txt infrastructure_icowts_tagged_20150426.txt

Step 2:
	1. Download TwitterSumm module from http://cse.iitkgp.ac.in/~krudra/TwitterSumm.tar.gz and extract it in Chapter_5 directory
	2. Go to directory TwitterSumm/TwitterSumm/absummarizer
	3. Run follwing path generation and ranker code: python koustav_path.py <tagged file>
		Sample run: python koustav_path.py infrastructure_icowts_tagged_20150426.txt
	4. Two files are generated => a. infrastructure_icowts_tagged_20150426.txt_paths b. infrastructure_icowts_tagged_20150426.txt_details.txt

	Note: Structure of path file: path \t average similarity of tweets which generate this path \t linguistic score of the path \t number of tweets combined to generate the path \t length of the path \t centroid score of the path

Step 3 (Concept extraction from paths):
	1. python extract_terms.py <path file> <place file> <output file>
	Sample run:  python extract_terms.py infrastructure_icowts_tagged_20150426.txt_paths nepal_place.txt infrastructure_path_concept_20150426.txt

################################################################# Final summarization step (combines tweets and paths) ##########################################
How to run: python extractive_abstractive_summary.py <concept file generated from original tweets> <concept file generated from paths> <place file> <keyword> <date> <word length>
Sample run: python extractive_abstractive_summary.py infrastructure_concept_20150426.txt infrastructure_path_concept_20150426.txt nepal_place.txt infrastructure 20150426 200

Final output file is infrastructure_exabs_20150426.txt
