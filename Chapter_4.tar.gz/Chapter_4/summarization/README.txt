################################################################# Concept extraction ##########################################################################
How to run: python extract_terms.py <input file> <place file> <output file>
Inputs:	1. input file format => Tweet ID \t Tweet \t Confidence score
	2. Place file contains information about locations
	3. output file contains concept details

Sample run: python extract_terms.py infrastructure_20150426.txt nepal_place.txt infrastructure_concept_20150426.txt

################################################################# Summarization ###############################################################################
How to run: python subevent_summary.py <input concept file> <input parse file> <input event tagged file> <place file> <keyword> <date> <word length>

Sample run: python subevent_summary.py infrastructure_concept_20150426.txt infrastructure_parsed_20150426.txt infrastructure_ner_20150426.txt nepal_place.txt infrastructure 20150426 200
