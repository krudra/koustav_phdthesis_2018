import sys
from collections import Counter
import re
from textblob import *
from gurobipy import *
import gzip
import os
import time
import codecs
import math
import networkx as nx
from nltk.corpus import stopwords
from nltk.corpus import wordnet
from nltk.corpus import wordnet_ic, genesis
from nltk.stem.wordnet import WordNetLemmatizer
import numpy as np
import aspell
from sklearn.cluster import AffinityPropagation
from sklearn import metrics
import pylab as pl
from itertools import cycle
from operator import itemgetter

LOWLIMIT = 0
UPPERLIMIT = 1

WT1 = 0.2
WT2 = 0.5
WT3 = 0.3

LSIM = 0.7
lmtzr = WordNetLemmatizer()
#Tagger_Path = '/home/krudra/summarization/summary_ilp/ark-tweet-nlp-0.3.2/'
ASPELL = aspell.Speller('lang', 'en')
WORD = re.compile(r'\w+')

#phone_string_1 = r"([0-9]{3,4}-[ \t]*[0-9]+[-[0-9]+]*)"
#phone_string_2 = r"([0-9]{10,})"
#phone_string_3 = r"([0-9]+-[0-9]+[-[0-9]+]*)"
#phone_string_4 = r"([0-9]{7,})"

cachedstopwords = stopwords.words("english")
AUX = ['be','can','cannot','could','am','has','had','is','are','may','might','dare','do','did','have','must','need','ought','shall','should','will','would','shud','cud','don\'t','didn\'t','shouldn\'t','couldn\'t','wouldn\'t']
NEGATE = ["aint", "arent", "cannot", "cant", "couldnt", "darent", "didnt", "doesnt",
              "ain't", "aren't", "can't", "couldn't", "daren't", "didn't", "doesn't",
              "dont", "hadnt", "hasnt", "havent", "isnt", "mightnt", "mustnt", "neither",
              "don't", "hadn't", "hasn't", "haven't", "isn't", "mightn't", "mustn't",
              "neednt", "needn't", "never", "none", "nope", "nor", "not", "nothing", "nowhere",
              "oughtnt", "shant", "shouldnt", "uhuh", "wasnt", "werent",
              "oughtn't", "shan't", "shouldn't", "uh-uh", "wasn't", "weren't",
              "without", "wont", "wouldnt", "won't", "wouldn't", "rarely", "seldom", "despite"]


def compute_summary(ifname,parsefile,eventfile,placefile,keyterm,date,Ts):

	###################################### Read Place Information ############################################################
	PLACE = {}
        fp = codecs.open(placefile,'r','utf-8')
        for l in fp:
                if PLACE.__contains__(l.strip(' \t\n\r').lower())==False:
                	PLACE[l.strip(' \t\n\r').lower()] = 1
        fp.close()

	######################################## Read Original Tweets #############################################################

	#Tweet = []
	#fp = codecs.open(ifname,'r','utf-8')
	#for l in fp:
	#	Tweet.append(l.strip(' \t\n\r'))
	#fp.close()

	######################################## Processing Parse File ###########################################################
	
	RPL = ['+','-',',','+91']
	#Topic = set([])
	index = 0
	count = 0
	dic = {}
	L = 0
	#print(ASPELL.check('vijaya'))
	#sword = {}
	#coword = {}
	#content = set([])
	#summary = {}
	#helpsum = []
	TAGREJECT = ['#','@','~','U','E','G',',']
	#chk = 'rt'

	fp = codecs.open(parsefile,'r','utf-8')
	fs = codecs.open(eventfile,'r','utf-8')
	ft = codecs.open(ifname,'r','utf-8')
	#ofname = keyterm + '_TSUM_' + date + '.txt'
	#fo = open(ofname,'w')
	#cover = []

        t0 = time.time()
	T = {}
	CT = {}
	SCT = {}
	content_count = {}
	notag_content_count = {}
	topic_count = {}
	TOPIC_SET = set([])

	for l in fp:
		wl = l.split('\t')
		if len(wl)==8:
                        #print(wl[0])
                        seq = int(wl[0])
                        main_word = wl[1].strip(' #\t\n\r').lower()
                        word = wl[1].strip(' #\t\n\r').lower()
                        tag = wl[4].strip(' \t\n\r')
                        dep = wl[6].strip(' \t\n\r')
                        if dep=='_':
                                dep = int(wl[7].strip(' \t\n\r'))
                        else:
                                dep = int(wl[6])

                        #if tag not in TAGREJECT:
                        #        count+=1

                        if tag=='$':
                                s = word.strip(' \t\n\r')
                                Q = s
                                for x in RPL:
                                        Q = s.replace(x,'')
                                        s = Q
                                Q = s.lstrip('0')
                                s = Q
                                #xx = re.findall(r"[/]",s)
                                #if len(xx)==0:
                                try:
                                	w = str(numToWord(int(s)))
                               		if len(w.split())>1: # like 67
                                        	w = s
                            	except Exception as e:
                                	w = str(s)
                                #else:
                                #        w = str(s)
                                #count+=1
                                word = w.lower()
                        elif tag=='N':
				try:
                                	w = lmtzr.lemmatize(word)
                                	#count+=1
                                	word = w.lower()
				except Exception as e:
					pass
                        elif tag=='^':
				try:
                                	w = lmtzr.lemmatize(word)
                                	#count+=1
                                	word = w.lower()
				except Exception as e:
					pass
				tag = 'N'
                        elif tag=='V':
                                try:
                                        w = Word(word.lower())
                                        x = w.lemmatize("v")
                                except Exception as e:
                                        x = word.lower()
                                word = x.lower()
                                #count+=1
                        else:
				pass

                        temp = [word,tag,dep,main_word]
                        dic[seq] = temp
			#if tag not in TAGREJECT:
			#	L+=1
		else:
			
			#################### Content Word Extraction ######################################################
			'''content = set([])
			All = set([])
			for k,v in dic.iteritems():
				if v[1] not in TAGREJECT:
					All.add(v[0])
				if PLACE.__contains__(v[0])==True:
					content.add((v[0],'P'))
				elif v[1]=='N' or v[1]=='V':
					if ASPELL.check(v[0])==1 and len(v[0])>1:
						if v[0] not in AUX and v[0] not in cachedstopwords and v[0] not in NEGATE:
							content.add((v[0],v[1]))
				elif v[1]=='$':
					content.add((v[0],v[1]))
				else:
					pass
					#if PLACE.__contains__(v[0])==True:
					#	content.add((v[0],'P')) '''

			#################### Subevent Extraction ############################################################
				
			EVENT = extract_events(fs.readline().strip(' \t\n\r'))
			ev = []
			for k,v in dic.iteritems():
				if v[1]=='V' and v[0] not in AUX and v[0] not in cachedstopwords and ASPELL.check(v[0])==1 and len(v[0])>1 and v[0] not in NEGATE:
					ev.append(k)
				elif EVENT.__contains__(v[0])==True and v[0] not in AUX and v[0] not in cachedstopwords and ASPELL.check(v[0])==1 and len(v[0])>1 and v[0] not in NEGATE:
					ev.append(k)
				else:
					pass
			topic = set([])
			for k,v in dic.iteritems():
				try:
					if v[2] in ev and v[1]=='N' and ASPELL.check(v[0])==1 and len(v[0])>1:
						topic.add((v[0],dic[v[2]][0]))
						TOPIC_SET.add((v[0],dic[v[2]][0]))
						#T[(v[0],dic[v[2]][0])] = 1
				except:
					print(v)

			content = set([])
			TL = ft.readline().split('\t')
			#print(TL)
			temp = TL[3].split()
			for x in temp:
				#content.add(x)
				x_0 = x.split('_')[0].strip(' \t\n\r')
				x_1 = x.split('_')[1].strip(' \t\n\r')
				if x_1=='PN':
					s = x_0 + '_CN'
					content.add(s)
				else:
					content.add(x)
				#content.add((x_0,x_1))
			All = set([])
			temp = TL[4].split()
			for x in temp:
				#content.add(x)
				x_0 = x.split('_')[0].strip(' \t\n\r')
				x_1 = x.split('_')[1].strip(' \t\n\r')
				if x_1=='PN':
					s = x_0 + '_CN'
					All.add(s)
				else:
					All.add(x)
				#content.add((x_0,x_1))
			#All = TL[6].split()
			#All = set([])
			#temp = TL[6].split()
			#for x in temp:
			#	x_0 = x.split('_')[0].strip(' \t\n\r')
			#	x_1 = x.split('_')[1].strip(' \t\n\r')
			#	content.add((x_0,x_1))
				
			L = int(TL[5])
			
			######################### SET COUNT #################################################################

			'''for x in content:
				if content_count.__contains__(x[0])==True:
					v = content_count[x[0]]
					v+=1
					content_count[x[0]] = v
				else:
					content_count[x[0]] = 1 '''

			for x in content:
				x10 = x.split('_')[0].strip(' \t\n\r')
				if notag_content_count.__contains__(x10)==True:
					v = notag_content_count[x10]
					v+=1
					notag_content_count[x10] = v
				else:
					notag_content_count[x10] = 1
			
			for x in content:
				if content_count.__contains__(x)==True:
					v = content_count[x]
					v+=1
					content_count[x] = v
				else:
					content_count[x] = 1

			for x in topic:
				if topic_count.__contains__(x)==True:
					v = topic_count[x]
					v+=1
					topic_count[x] = v
				else:
					topic_count[x] = 1

			'''cluster_topic = set([])
			for x in topic:
				try:
					cluster_topic.add(EVCL[x])
				except Exception as e1:
					missed_subevent.add(x)'''
			
			#k = should_select(CT,content)
			k = should_select(SCT,All)
			if k==1:
				CT[index] = content
				SCT[index] = All
				T[index] = [TL[2].strip(' \t\n\r'),content,topic,L]
				#T[index] = [Tweet[count],content,cluster_topic,L]
				index+=1

			dic = {}
			#L = 0
			count+=1
       
	fp.close()
	fs.close()
	ft.close()
	print(count,index)

	'''temp = set([])
	for i in range(0,index,1):
		v = T[i][1]
		for x in v:
			temp.add(x)
	print('Content words: ',len(temp))'''



	'''
	G = nx.DiGraph()
	for i in range(0,index,1):
		G.add_node(i)
	for i in range(0,index-1,1):
		for j in range(i+1,index,1):
			sim = compute_similarity(T[i][1],T[j][1])
			G.add_edge(i,j,weight=sim)
	pr = nx.pagerank(G,max_iter=5000,weight='weight')
	TWEET_WEIGHT = set_weight(pr,LOWLIMIT,UPPERLIMIT)
	'''


	'''
	ofname = keyterm + '_tweetweight_' + date + '.txt'
	fo = codecs.open(ofname,'w','utf-8')
	for i in range(0,index,1):
		fo.write(T[i][0] + '\t' + str(TWEET_WEIGHT[i]) + '\n')
	fo.close()
	'''	

	########################################### Develop Clusters from Topic ################################################
	
	
	'''TOPIC_SET = list(TOPIC_SET)
	dic = {}
        for i in range(0,len(TOPIC_SET),1):
                N = TOPIC_SET[i][0]
                V = TOPIC_SET[i][1]
                if dic.__contains__(N)==True:
                        v = dic[N]
                        v.add(V)
                        dic[N] = v
                else:
                        v = set([])
                        v.add(V)
                        dic[N] = v'''

	'''
	fo = codecs.open('subevent_cluster.txt','w','utf-8')
	for k,v in dic.iteritems():
		s = ''
		for x in v:
			s = s + x + ' '
		fo.write(k + '\t' + s.strip(' ') + '\n')
	fo.close()
	sys.exit(0)	
	'''
	

	'''cluster_count = 0
	EVCL = {}
	REVCL = {}
	for k,v in dic.iteritems():
		name = 'subevent_' + str(cluster_count)
		temp = set([])
		for x in v:
			t = (k,x)
			EVCL[t] = name
			temp.add(t)
		REVCL[name] = temp
		cluster_count+=1'''
	
	#CONTENT_WEIGHT = compute_tfidf_content(content_count,count,PLACE)
	CONTENT_WEIGHT = compute_tfidf_NEW(content_count,count,PLACE)
	#TOPIC_WEIGHT = compute_tfidf_topic(topic_count,count)
	TOPIC_WEIGHT = compute_pmi_topic(topic_count,notag_content_count)
	'''TOPIC_CLUSTER_WEIGHT = {}
	for k,v in REVCL.iteritems():
		temp = []
		for x in v:
			temp.append(TOPIC_WEIGHT[x])
		if len(temp)>0:
			#TOPIC_CLUSTER_WEIGHT[k] = round(np.mean(temp),4)
			TOPIC_CLUSTER_WEIGHT[k] = round(max(temp),4)
		else:
			TOPIC_CLUSTER_WEIGHT[k] = 0.0'''
	NORM_CONTENT_WEIGHT = set_weight(CONTENT_WEIGHT,LOWLIMIT,UPPERLIMIT)
	#NORM_TOPIC_WEIGHT = set_weight(TOPIC_WEIGHT,LOWLIMIT,UPPERLIMIT)
	#NORM_CONTENT_WEIGHT = CONTENT_WEIGHT
	NORM_TOPIC_WEIGHT = TOPIC_WEIGHT

	########################################### Update Tweet Set (topic to cluster) ########################################
	
	TW = {}
	for i in range(0,index,1):
		v = T[i]
		'''temp = v[2]
		event_cl = set([])
		for x in temp:
			event_cl.add(EVCL[x])'''
		# If tweet contains subevent then do not consider nouns and verbs as content words
		#temp = v[1]
		#mod_content = set([])
		#for x in temp:
		#	mod_content.add(x[0])

		temp = v[2]
		mod_sub = set([])
		for x in temp:
			#if TOPIC_WEIGHT[x] > 0:
			mod_sub.add(x)

		#TW[i] = [v[0],mod_content,mod_sub,v[3],1]
		TW[i] = [v[0],v[1],mod_sub,v[3],1]
	

	########################################### Compute Content Word and Topic Weight ######################################

	#CONTENT_WEIGHT = compute_tfidf_content(content_count,count,PLACE)
	#TOPIC_WEIGHT = compute_tfidf_topic(topic_count,count)
	'''TOPIC_CLUSTER_WEIGHT = {}
	for k,v in REVCL.iteritems():
		temp = []
		for x in v:
			temp.append(TOPIC_WEIGHT[x])
		if len(temp)>0:
			#TOPIC_CLUSTER_WEIGHT[k] = round(np.mean(temp),4)
			TOPIC_CLUSTER_WEIGHT[k] = round(max(temp),4)
		else:
			TOPIC_CLUSTER_WEIGHT[k] = 0.0'''

	#NORM_CONTENT_WEIGHT = set_weight(CONTENT_WEIGHT,LOWLIMIT,UPPERLIMIT)
	#NORM_TOPIC_WEIGHT = set_weight(TOPIC_WEIGHT,LOWLIMIT,UPPERLIMIT)
	#NORM_TOPIC_WEIGHT = set_weight(TOPIC_WEIGHT,LOWLIMIT,UPPERLIMIT)

	'''
	fo = codecs.open('generic_score.txt','w','utf-8')
	for k,v in NORM_CONTENT_WEIGHT.iteritems():
		fo.write(k + '\t' + str(CONTENT_WEIGHT[k]) + '\t' + str(v) + '\n')
		#print(k,v,CONTENT_WEIGHT[k])
	for k,v in NORM_TOPIC_WEIGHT.iteritems():
		fo.write(k[0] + ' ' + k[1] + '\t' + str(TOPIC_WEIGHT[k]) + '\t' + str(v) + '\n')
		#print(k,v,TOPIC_WEIGHT[k])

	fo = codecs.open('mod_subevent.txt','w','utf-8')
	for i in range(0,len(TW.keys()),1):
		temp = TW[i]
		#if len(temp[2])==0:
		s = ''
		for x in temp[1]:
			s = s + x + ' '
		s_e = ''
		for x in temp[2]:
			s_e = s_e + x + ' '
			#s_e = s_e + x[0] + '||' + x[1] + ' '
		fo.write(temp[0].strip(' \t\n\r') + '\t' + s.strip(' ') + '\t' + s_e.strip(' ') + '\n')
	fo.close()
	sys.exit(0)
	'''

	########################################## Summarize Tweets #############################################################

	L = len(TW.keys())
        tweet_cur_window = {}
        for i in range(0,L,1):
                temp = TW[i]
                tweet_cur_window[i] = [temp[0].strip(' \t\n\r'),int(temp[3]),temp[1],temp[2],float(temp[4])] # tweet, length, content, topic

        ofname = keyterm + '_test_' + date + '.txt'
        optimize(tweet_cur_window,NORM_CONTENT_WEIGHT,NORM_TOPIC_WEIGHT,ofname,Ts,0.4,0.6)
        #optimize(tweet_cur_window,CONTENT_WEIGHT,TOPIC_WEIGHT,ofname,Ts,0.4,0.6)
        t1 = time.time()
        print('Summarization done: ',ofname,' ',t1-t0)

def compute_similarity(S1,S2):
	common = set(S1).intersection(set(S2))
	X = len(common) + 4.0 - 4.0
	Y = min(len(S1),len(S2)) + 4.0 - 4.0
	if Y==0:
		return 0
	Z = round(X/Y,4)
	return Z

def should_select(T,new):
        #y = len(new) + 4.0 - 4.0
        if len(new)==0:
                return 0
        for i in range(0,len(T),1):
                temp = T[i]
                common = set(temp).intersection(set(new))
                if len(common)==len(new):
                       return 0
        return 1
'''
def should_select(T,new):
        #y = len(new) + 4.0 - 4.0
        if len(new)==0:
                return 0
        for i in range(0,len(T),1):
                temp = T[i]
                common = set(temp).intersection(set(new))
                #if len(common)==len(new):
                #       return 0
                y = min(len(temp),len(new)) + 4.0 - 4.0
                x = len(common) + 4.0 - 4.0
                z = round(x/y,2)
                #print(z)
                if z >= 0.80:
                        return 0
        return 1
'''
def check_phone_number(dic):
	for k,v in dic.iteritems():
		if v[1]=='$':
			P1 = re.findall(phone_string_1,v[0])
			P2 = re.findall(phone_string_2,v[0])
			P3 = re.findall(phone_string_3,v[0])
			P4 = re.findall(phone_string_4,v[0])
			if len(P1)>0 or len(P2)>0 or len(P3)>0 or len(P4)>0:
				return 1
	return 0

def concept_overlap(new,cover,T):
	cover = list(set(cover))
	C1 = set([])
	v = T[new]
	for x in v:
		C1.add(x[0])
	
	SIM = []
	for y in cover:
		v = T[y]
		C2 = set([])
		for x in v:
			C2.add(x[0])
		X = len(C1.intersection(C2)) + 4.0 - 4.0
		Y = min(len(C1),len(C2)) + 4.0 - 4.0
		Z = round(X/Y,2)
		SIM.append(Z)
	if len(SIM)==0:
		return 0
	return(max(SIM))

def vertex_cover(topic):
	G = nx.Graph()
	for k,v in topic.iteritems():
		G.add_node(k)
	
	Node = G.nodes()
	for i in range(0,len(Node)-1,1):
		W1 = set([])
		temp = topic[Node[i]]
		for x in temp:
			W1.add(x[0])
		for j in range(i+1,len(Node),1):
			W2 = set([])
			temp = topic[Node[j]]
			for x in temp:
				W2.add(x[0])
			X = len(W1.intersection(W2)) + 4.0 - 4.0
			Y = min(len(W1),len(W2)) + 4.0 - 4.0
			Z = round(X/Y,2)
			G.add_edge(Node[i],Node[j],weight=Z)
	
	#print(G.edges(data=True))
	vc = nx.min_weighted_vertex_cover(G)
	#vc = G.min_weighted_vertex_cover(weight='weight')
	return vc

def extract_events(line):
	EVENT = {}
	wl = line.split()
	for w in wl:
		X = w.split('/')
		if X[len(X)-1]=='B-EVENT' and X[len(X)-2].startswith('V')==True and len(X[0])>2:
			word = X[0].strip(' \t\n\r').lower()
			try:
				y = Word(word)
				z = y.lemmatize("v")
				word = z
			except Exception as e:
				print(e)
				pass
                                #sys.exit(0)
                                #x = word
			if EVENT.__contains__(word)==False:
				EVENT[word] = 1
                                #temp.add(word)
        return EVENT
		
def set_sigmoid_weight(P):
        '''temp = []
        for k,v in weight.iteritems():
                temp.append(v)
        temp.sort()'''
	temp = P.values()
	mean = np.mean(temp)
	std = np.std(temp)
	
        mod_P = {}
	for k,v in P.iteritems():
		X = v - mean + 4.0 - 4.0
		Y = std + 4.0 - 4.0
		score = abs(round(X/Y,4))
		mod_P[k] = score
		
        count = 0
        #print(mod_P[0],mod_P[1])
        for k,v in mod_P.iteritems():
                print(k,v)
                count+=1
                if count==10:
                        break
	
        return mod_P

def set_weight(P,L,U):
        '''temp = []
        for k,v in weight.iteritems():
                temp.append(v)
        temp.sort()'''
        min_p = min(P.values())
        max_p = max(P.values())

        x = U - L + 4.0 - 4.0
        y = max_p - min_p + 4.0 - 4.0
        factor = round(x/y,4)

        mod_P = {}
	for k,v in P.iteritems():
		val = L + factor * (v - min_p)
		mod_P[k] = round(val,4)

        count = 0
        #print(mod_P[0],mod_P[1])
        '''for k,v in mod_P.iteritems():
                print(k,v)
                count+=1
                if count==10:
                        break'''
        return mod_P

def wordnet_similarity(word1,word2,brown_ic,semcor_ic):

        '''sim_1 = word1.lin_similarity(word2, brown_ic)
        sim_2 = word1.lin_similarity(word2, semcor_ic)
        sim_3 = word1.lin_similarity(word2, genesis_ic)
        sim = max(sim_1,sim_2,sim_3)
        return sim'''

        cbv = wordnet.synsets(word1)
        ibv = wordnet.synsets(word2)
        #print(cbv, ibv)

        MAX = []
        for i in range(0,len(cbv),1):
                w1 = wordnet.synset(cbv[i].name())
                for j in range(0,len(ibv),1):
                        w2 = wordnet.synset(ibv[j].name())
                        #MAX.append(w1.wup_similarity(w2))
                        try:
                                sim_1 = w1.lin_similarity(w2, brown_ic)
                                #sim_1 = w1.lin_similarity(w2, semcor_ic)
                                #sim_2 = w1.lin_similarity(w2, semcor_ic)
                                #sim_3 = w1.lin_similarity(w2, genesis_ic)
                                #MAX.append(max(sim_1,sim_2,sim_3))
                                MAX.append(sim_1)
                        except Exception as e:
                                pass

        #print(max(MAX))
        try:
                m = max(MAX)
                if m==None:
                        m = 0
		m = abs(m)
		#if m<=0.20:
		#	m = 0
                return m
        except Exception as e:
                return 0

def affinity_clustering(S):
        af = AffinityPropagation().fit(S)
        cluster_centers_indices = af.cluster_centers_indices_
        labels = af.labels_
        n_clusters_ = len(cluster_centers_indices)
        #print 'Estimated number of clusters: %d' % n_clusters_

        '''print 'Homogeneity: %0.3f' % metrics.homogeneity_score(labels_true, labels)
        print 'Completeness: %0.3f' % metrics.completeness_score(labels_true, labels)
        print 'V-measure: %0.3f' % metrics.v_measure_score(labels_true, labels)
        print 'Adjusted Rand Index: %0.3f' % metrics.adjusted_rand_score(labels_true, labels)
        print 'Adjusted Mutual Information: %0.3f' % metrics.adjusted_mutual_info_score(labels_true, labels)
        D = (S / np.min(S))
        print ('Silhouette Coefficient: %0.3f' % metrics.silhouette_score(D, labels, metric='precomputed'))'''
        #print(cluster_centers_indices)
        #print(labels)

        L = [cluster_centers_indices,labels]

        #return cluster_centers_indices
        return L

        '''for k, col in zip(range(n_clusters_), colors):
                class_members = labels == k
                cluster_center = X[cluster_centers_indices[k]]
                pl.plot(X[class_members, 0], X[class_members, 1], col + '.')
                pl.plot(cluster_center[0], cluster_center[1], 'o', markerfacecolor=col,markeredgecolor='k', markersize=14)
                for x in X[class_members]:
                        pl.plot([cluster_center[0], x[0]], [cluster_center[1], x[1]], col)

        pl.title('Estimated number of clusters: %d' % n_clusters_)
        pl.show()'''

def compute_coweight(coword,word,count):
        coscore = {}
        exc = 0
        for k,v in coword.iteritems():
                s1 = k[0]
                s2 = k[1]
                #x1 = v + 4.0 - 4.0
                #x2 = min(word[s1],word[s2]) + 4.0 - 4.0
                #x3 = round(x1/x2,4)
                #coscore[k] = x3
                den = word[s1] * word[s2]
                num = count * v
                x1 = num + 4.0 - 4.0
                x2 = den + 4.0 - 4.0
                x3 = v + 4.0 - 4.0
                x4 = v + 1 + 4.0 - 4.0
                x5 = round(x3/x4,4)
                x6 = min(word[s1],word[s2]) + 4.0 - 4.0
                x7 = min(word[s1],word[s2]) + 1 + 4.0 - 4.0
                x8 = round(x6/x7,4)
                try:
                        p = round(x1/x2,4)
                        p1 = math.log(p,2) * x5 * x8
                        if p1 < 0:
                                p1 = 0
                        coscore[k] = p1
                except Exception as e:
                        coscore[k] = 0
                        exc+=1
        print('Got exception ', exc, ' times')

        count = 0
        for k,v in coscore.iteritems():
                print(k,v)
                count+=1
                if count>=20:
                        break
        return coscore

def compute_simpson(coword,word,count):
        coscore = {}
        exc = 0
        for k,v in coword.iteritems():
                s1 = k[0]
                s2 = k[1]
                x1 = v + 4.0 - 4.0
                x2 = min(word[s1],word[s2]) + 4.0 - 4.0
                x3 = round(x1/x2,4)
                coscore[k] = x3

        count = 0
        for k,v in coscore.iteritems():
                print(k,v)
                count+=1
                if count>=20:
                        break
        return coscore

def build_community(T):
	L = len(T.keys())
	sim = {}
	for i in range(0,L,1):
		F1 = T[i]
		for j in range(i,L,1):
			F2 = T[j]
			s = select_cluster(F1,F2)
			sim[(i,j)] = round(s,4)
	S = []
	for i in range(0,L,1):
		temp = []
		for j in range(0,L,1):
			if i<=j:
				temp.append(sim[(i,j)])
			else:
				temp.append(sim[(j,i)])
		S.append(temp)
	
	index = 0
	fo = open('temp_input.txt','w')
	for List in S:
		for i in range(0,len(List),1):
			if index!=i and i > index:
				if List[i] > 0:
					s = str(index) + ' ' + str(i) + ' ' + str(List[i])
					fo.write(s)
					fo.write('\n')
		index+=1
	fo.close()

	command = INFOPATH + './Infomap temp_input.txt out/ -N 10  --zero-based-numbering --two-level --clu'
	os.system(command)

	fp = open('out/temp_input.clu','r')
	index = 0
	community = {}
	for l in fp:
		if index>=2:
			wl = l.split()
			c = int(wl[1])
			if community.__contains__(c)==True:
				v = community[c]
				v.append(int(wl[0]))
				community[c] = v
			else:
				community[c] = [int(wl[0])]
		index+=1
	'''command = 'rm temp_input.txt'
	os.system(command)'''
	return community

def optimize(tweet,con_weight,sub_weight,ofname,L,A1,A2):


        ################################ Extract Tweets and Content Words ##############################
        con_word = {}
	sub_word = {}
        tweet_word = {}
        tweet_index = 1
        for  k,v in tweet.iteritems():
                set_of_words = v[2]
                for x in set_of_words:
                	if con_word.__contains__(x)==False:
                                #word[x] = 1
                                if con_weight.__contains__(x)==True:
                                        p1 = round(con_weight[x],4)
                                else:
                                        p1 = 0.0
                                con_word[x] = p1 * WT2
                                #con_word[x] = WT2
                
		set_of_subs = v[3]
                for x in set_of_subs:
                	if sub_word.__contains__(x)==False:
                                #word[x] = 1
                                if sub_weight.__contains__(x)==True:
                                        p1 = round(sub_weight[x],4)
                                else:
                                        p1 = 0.0
                                sub_word[x] = p1 * WT3
                                #sub_word[x] = WT3

                tweet_word[tweet_index] = [v[1],set_of_words,set_of_subs,v[0],v[4]]  #Length of tweet, set of content words present in the tweet, set of subevents present in the tweet, tweet itself
                tweet_index+=1

        ############################### Make a List of Tweets ###########################################
        sen = tweet_word.keys()
        sen.sort()
        entities = con_word.keys()
	subevents = sub_word.keys()
        print(len(sen),len(entities),len(subevents))

        ################### Define the Model #############################################################

        m = Model("sol1")

        ############ First Add tweet variables ############################################################

        sen_var = []
        for i in range(0,len(sen),1):
                sen_var.append(m.addVar(vtype=GRB.BINARY, name="x%d" % (i+1)))
                '''var = 'x' + str(sen[i])
                var1 = '"' + var + '"'
                var = m.addVar(vtype=GRB.BINARY, name=var1)'''

        ############ Add entities variables ################################################################

        con_var = []
        for i in range(0,len(entities),1):
                con_var.append(m.addVar(vtype=GRB.BINARY, name="y%d" % (i+1)))
                '''var = 'y' + str(i+1)
                var1 = '"' + var + '"'
                var = m.addVar(vtype=GRB.BINARY, name=var1)'''
        
	############ Add subevents variables ################################################################

        sub_var = []
        for i in range(0,len(subevents),1):
                sub_var.append(m.addVar(vtype=GRB.BINARY, name="z%d" % (i+1)))
                '''var = 'z' + str(i+1)
                var1 = '"' + var + '"'
                var = m.addVar(vtype=GRB.BINARY, name=var1)'''

        ########### Integrate Variables ####################################################################
        m.update()

	'''for i in range(0,len(entities),1):
                print(i,entities[i])
        sys.exit(0)'''
        P = LinExpr() # Contains objective function
        C1 = LinExpr()  # Summary Length constraint
        C4 = LinExpr()  # Summary Length constraint
        C2 = [] # If a tweet is selected then the content words are also selected
        counter = -1
        for i in range(0,len(sen),1):
                #P += tweet_word[i+1][4] * sen_var[i] * WT1
                P += sen_var[i] * WT1
                C1 += tweet_word[i+1][0] * sen_var[i]
                #C1 += sen_var[i]
                v = tweet_word[i+1][1] # Entities present in tweet i+1
                #print(v)
                C = LinExpr()
                flag = 0
                for j in range(0,len(entities),1):
                        if entities[j] in v:
                                flag+=1
                                C += con_var[j]
                if flag>0:
                        #print(C,flag)
                        counter+=1
                        m.addConstr(C, GRB.GREATER_EQUAL, flag * sen_var[i], "c%d" % (counter))
                
                v = tweet_word[i+1][2] # Subevents present in tweet i+1
		C = LinExpr()
                flag = 0
                for j in range(0,len(subevents),1):
                        if subevents[j] in v:
                                flag+=1
                                C += sub_var[j]
                if flag>0:
                        #print(C,flag)
                        counter+=1
                        m.addConstr(C, GRB.GREATER_EQUAL, flag * sen_var[i], "c%d" % (counter))

                #s = C + GRB.GREATER_EQUAL + str(len(v))
                #C2.append(s)
                #decl = decl + 'x' + str(i+1) + ' , '

        #C3 = [] # If a content word is selected then at least one tweet is selected which contains this word
        #C4 = ''
        for i in range(0,len(entities),1):
                P += con_word[entities[i]] * con_var[i]
                #P += con_var[i]
                #C4 = C4 + 'y' + str(i+1) + ' + '
                C = LinExpr()
                flag = 0
                for j in range(0,len(sen),1):
                        v = tweet_word[j+1][1]
                        if entities[i] in v:
                                flag = 1
                                C += sen_var[j]
                if flag==1:
                        counter+=1
                        m.addConstr(C,GRB.GREATER_EQUAL,con_var[i], "c%d" % (counter))
                #s = LinExpr()
                #s = C + ' >= ' + con_var[i]
                #C3.append(s)
                #decl = decl + 'y' + str(i+1) + ' , '
        

	for i in range(0,len(subevents),1):
                P += sub_word[subevents[i]] * sub_var[i]
                #P += con_var[i]
                #C4 = C4 + 'y' + str(i+1) + ' + '
                C = LinExpr()
                flag = 0
                for j in range(0,len(sen),1):
                        v = tweet_word[j+1][2]
                        if subevents[i] in v:
                                flag = 1
                                C += sen_var[j]
                if flag==1:
                        counter+=1
                        m.addConstr(C,GRB.GREATER_EQUAL,sub_var[i], "c%d" % (counter))
                #s = LinExpr()
                #s = C + ' >= ' + con_var[i]
                #C3.append(s)
                #decl = decl + 'y' + str(i+1) + ' , '

        #s = P.strip(' +') + ' );'
        #s = P.strip(' +')
        #P = s
        #fo.write(P)
	#fo.write('\n')
        #m.addConstr(C1,GRB.LESS_EQUAL,L,"c0")
        #K = 40
        counter+=1
        m.addConstr(C1,GRB.LESS_EQUAL,L, "c%d" % (counter))


        ################ Set Objective Function #################################
        #print(P)
        m.setObjective(P, GRB.MAXIMIZE)
        #m.setObjective(x + y + 2 * z, GRB.MAXIMIZE)

        ############### Set Constraints ##########################################

        fo = codecs.open(ofname,'w','utf-8')
        try:
                m.optimize()
                for v in m.getVars():
                        if v.x==1:
                                temp = v.varName.split('x')
                                if len(temp)==2:
					X = ''
					EV = tweet_word[int(temp[1])][2]
					if len(EV)!=0:
						for x in EV:
							X = X + x[0] + '$#@' + x[1] + ' '
						X = X.strip(' ')
					else:
						X = 'NIL'
                                        #z = ''
                                        #for b in tweet_word[int(temp[1])][1]:
                                        #       z = z + b + ' '
                                        #s = str(tweet_c) + '\t' + tweet_word[int(temp[1])][3] + '\t' + tweet_word[int(temp[1])][2] + '\t' + z.strip(' ') + '\t' + str(tweet_word[int(temp[1])][0]) + '\t' + str(tweet_word[int(temp[1])][4])
                                        #fo.write(X + ':\t' + tweet_word[int(temp[1])][3])
                                        fo.write(tweet_word[int(temp[1])][3])
                                        #fo.write(s)
                                        fo.write('\n')
        except GurobiError as e:
                print(e)
                sys.exit(0)

        fo.close()


'''def compute_tfidf_content(word,tweet_count,PLACE):
        score = {}
	discard = []
        #discard = ['pray','prayer','updates','pls','please','hope','hoping','breaking','news','flash','update','tweet','pm','a/c','v/','w/o','watch','photo','video','picture','screen','pics','latest','plz','rt','mt','follow','tv','pic','-mag','cc','-please','soul','hoax','a/n','utc','some','something','ist','afr','guru','image','images']

        #THR = int(round(math.log10(tweet_count),0))
        THR = 5
	for k,v in word.iteritems():
        	if k not in discard:
                        tf = v
                        w = 1 + math.log(tf,2)
                        df = v + 4.0 - 4.0
                        N = tweet_count + 4.0 - 4.0
                        try:
                                y = round(N/df,4)
                                idf = math.log10(y)
                        except Exception as e:
                                idf = 0
                        val = round(w * idf, 4)
                        
			if PLACE.__contains__(k)==True:
                        	score[k] = val
                        elif tf>=THR:
                                score[k] = val
                        else:
                                score[k] = 0
                else:
                        score[k] = 0
        return score'''

def compute_tfidf_NEW(word,tweet_count,PLACE):
        score = {}
        #discard = ['pray','prayer','updates','pls','please','hope','hoping','breaking','news','flash','update','tweet','pm','a/c','v/','w/o','watch','photo','video','picture','screen','pics','latest','plz','rt','mt','follow','tv','pic','-mag','cc','-please','soul','hoax','a/n','utc','some','something','ist','afr','guru','image','images']

        discard = []
        #THR = int(round(math.log10(tweet_count),0))
        THR = 5
        N = tweet_count + 4.0 - 4.0
        for k,v in word.iteritems():
                D = k.split('_')
                D_w = D[0].strip(' \t\n\r')
                D_t = D[1].strip(' \t\n\r')
                if D_w not in discard:
                        tf = v
                        w = 1 + math.log(tf,2)
                        #w = tf
                        df = v + 4.0 - 4.0
                        #N = tweet_count + 4.0 - 4.0
                        try:
                                y = round(N/df,4)
                                idf = math.log10(y)
                        except Exception as e:
                                idf = 0
                        val = round(w * idf, 4)
                        if D_t=='P' and tf>=THR:
                                score[k] = val
                        elif tf>=THR and D_t=='S':
                                score[k] = val
                        elif tf>=THR and len(D_w)>2:
                                score[k] = val
                        else:
                                score[k] = 0
                else:
                        score[k] = 0
        return score

def compute_pmi_topic(topic_count,content_count):
	TOPIC = []
        for k,v in topic_count.iteritems():
                try:
                        x1 = k[0]
                        x2 = k[1]
                        w1 = content_count[x1]
                        w2 = content_count[x2]
                        y1 = v + 4.0 - 4.0
                        #y2 = (w1 * w2) + 4.0 - 4.0
                        y2 = min(w1,w2) + 4.0 - 4.0
                        #y2 = w1 + w2  + 4.0 - 4.0
                        #z = math.log(y1*count/y2,2)
                        z = round(y1/y2,4)

                        p1 = v + 4.0 - 3.0
                        p2 = y1/p1
                        q1 = min(w1,w2) + 4.0 - 4.0
                        q2 = min(w1,w2) + 4.0 - 3.0
                        q3 = q1/q2

                        PMI = round(z*p2*q3,4)
                        #PMI = z
                        #if w1 >=10 and w2 >= 10 and v>=10:
                        TOPIC.append((k,v,w1,w2,PMI))
                except Exception as e:
                        pass
	score = {}
	for T in TOPIC:
		if T[1]>=5 and T[2]>=10 and T[3]>=10:
			score[T[0]] = T[4]
		else:
			score[T[0]] = 0
	print('Score count: ',len(score.keys()))
	return score

def compute_tfidf_topic(word,tweet_count):
        score = {}
	discard = []
        #discard = ['pray','prayer','updates','pls','please','hope','hoping','breaking','news','flash','update','tweet','pm','a/c','v/','w/o','watch','photo','video','picture','screen','pics','latest','plz','rt','mt','follow','tv','pic','-mag','cc','-please','soul','hoax','a/n','utc','some','something','ist','afr','guru','image','images']

        #THR = int(round(math.log10(tweet_count),0))
        THR = 5
	for k,v in word.iteritems():
        	if k not in discard:
                        tf = v
                        w = 1 + math.log(tf,2)
                        df = v + 4.0 - 4.0
                        N = tweet_count + 4.0 - 4.0
                        try:
                                y = round(N/df,4)
                                idf = math.log10(y)
                        except Exception as e:
                                idf = 0
                        val = round(w * idf, 4)
                        
                        if tf>=THR:
                                score[k] = val
                        else:
                                score[k] = 0
                else:
                        score[k] = 0
        return score

def select_cluster(F1,F2):
        s = ''
        for x in F1:
		wl = x.split('_')
		word = wl[0].strip(' \t\n\r')
		tag = wl[1].strip(' \t\n\r')
		if tag=='N' or tag=='V':
                	s = s + x + ' '
        s1 = s.strip(' ')
        vec1 = text_to_vector_tf(s1) #Convert new one'''

	s = ''
        for x in F2:
		wl = x.split('_')
		word = wl[0].strip(' \t\n\r')
		tag = wl[1].strip(' \t\n\r')
		if tag=='N' or tag=='V':
                	s = s + x + ' '
	s1 = s.strip(' ')
	vec2 = text_to_vector_tf(s1)
	cos = get_cosine(vec1,vec2)
	return cos

def get_cosine(vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])
        sum1 = sum([vec1[x]**2 for x in vec1.keys()])
        sum2 = sum([vec2[x]**2 for x in vec2.keys()])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
                return 0.0
        else:
                return float(numerator) / denominator

def text_to_vector_tf(text):
        words = WORD.findall(text)
        return Counter(words)

def get_max_sim(T,index):
	
	if index==0:
		return 0

	temp = T[index][4]
	s = ''
	for x in temp:
		s = s + x + ' '
	s1 = s.strip(' ')
        vec1 = text_to_vector_tf(s1) #Convert new one'''
	
	SIM = []
	for i in range(0,index,1):
		s = ''
		temp = T[i][4]
		for x in temp:
			s = s + x + ' '
		s1 = s.strip(' ')
        	vec2 = text_to_vector_tf(s1)
		cos = get_cosine(vec1,vec2)
		SIM.append(cos)
	SIM.sort()
	SIM.reverse()
	return SIM[0]

def apsalience(tweet,ofname,L):
	T = []
	s = ''
	for k,v in tweet.iteritems():
		T.append((k,v[0],v[1],v[2]))

	T.sort(key=itemgetter(3),reverse=True)

	fo = codecs.open('getR.txt','w','utf-8')
	for x in T:
		fo.write(x[1])
		fo.write('\n')
	fo.close()

	command = Tagger_Path + './runTagger.sh --output format conll getR.txt > tag.txt'
	os.system(command)
	
	P = []
	TAGREJECT = ['@','#',',','~','U','E','G']
	fp = codecs.open('tag.txt','r','utf-8')
	index = 0
	temp = []
	for l in fp:
		wl = l.split()
		if len(wl) > 1:
			word = wl[0].strip(' #\t\n\r').lower()
			tag = wl[1].strip(' \t\n\r')
			if tag not in TAGREJECT and word not in cachedstopwords:
				temp.append(word)
		else:
			q = T[index]
			P.append((q[0],q[1],q[2],q[3],temp))
			index+=1
			temp = []
	fp.close()

	P.sort(key=itemgetter(3),reverse=True)
	count = 0
	fo = codecs.open(ofname,'w','utf-8')
	for i in range(0,len(P),1):
		sim = get_max_sim(P,i)
		if sim < LSIM:
			fo.write(P[i][1])
			fo.write('\n')
			count+=P[i][2]
			if count>=L:
				break
	fo.close()
		
def Normalize(M):
	m = max(M)
	y = m + 4.0 - 4.0
	P = []
	for i in range(0,len(M),1):
		x = M[i] + 4.0 - 4.0
		z = round(x/y,4)
		P.append(z)
	return P	

def compute_tfidf_not(word,tweet_count,PLACE):

        score = {}
        discard = ['pray','prayer','updates','pls','please','hope','hoping','breaking','news','flash','update','tweet','pm','a/c','v/','w/o','watch','photo','video','picture','screen','pics','latest','plz','rt','mt','follow','tv','pic','-mag','cc','-please','soul','hoax','a/n','utc','some','something','ist','afr','guru','image','images']

        #THR = int(round(math.log10(tweet_count),0))
        THR = 5
        for k,v in word.iteritems():
                if k not in discard:
                        tf = v[0]
                        w = 1 + math.log(tf,2)
                        df = len(v[1]) + 4.0 - 4.0
                        N = tweet_count + 4.0 - 4.0
                        try:
                                y = round(N/df,4)
                                idf = math.log10(y)
                        except Exception as e:
                                idf = 0
                        val = round(w * idf, 4)
                        #if tf>=5:
                                # Consider a word if it occurs more than 10 times or its tf-idf score crosses 10
                         #       score[k] = val
                        #else:
                        PX = re.findall(r'[\d]+',k)
                        if PLACE.__contains__(k)==True:
                                score[k] = val
                        elif len(PX)>=1 and k.find('/')==-1:
                                score[k] = val
                        elif ASPELL.check(k)==1 and tf>=THR:
                                score[k] = val
                        else:
                                score[k] = 0
                else:
                        score[k] = 0
        return score

def numToWord(number):
        word = []
        if number < 0 or number > 999999:
                return number
                # raise ValueError("You must type a number between 0 and 999999")
        ones = ["","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"]
        if number == 0: return "zero"
        if number > 9 and number < 20:
                return ones[number]
        tens = ["","ten","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"]
        word.append(ones[int(str(number)[-1])])
        if number >= 10:
                word.append(tens[int(str(number)[-2])])
        if number >= 100:
                word.append("hundred")
                word.append(ones[int(str(number)[-3])])
        if number >= 1000 and number < 1000000:
                word.append("thousand")
                word.append(numToWord(int(str(number)[:-3])))
        for i,value in enumerate(word):
                if value == '':
                        word.pop(i)
        return ' '.join(word[::-1])


def main():
	try:
		_, ifname, parsefile, eventfile, placefile, keyterm, date, Ts = sys.argv
	except Exception as e:
		print(e)
		sys.exit(0)
	compute_summary(ifname,parsefile,eventfile,placefile,keyterm,date,int(Ts))
	print('Koustav Done')

if __name__=='__main__':
	main()
