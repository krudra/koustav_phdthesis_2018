How to run: python extract_rank_subevent.py <parsed input file> <entity tagged file> <output file>

Input =>
	1. input parsed file contains dependency relations of tweets [done using Twitter parser (Kong Emnlp 2014)]
	2. file contains Entity and event tagged tweets [done using Twitter NER tagger (Ritter ACL 2011)]
	3. output file : Noun \t Verb \t Co-occurrence count \t Frequency of noun \t Frequency of verb \t Simpson score

Sample run: python extract_run_subevent.py infrastructure_parsed_20150426.txt infrastructure_ner_20150426.txt infrastructure_subevent_20150426.txt

Note:   1. entity file can be skipped from the code if we want to get output fast
	2. This code extracts all the noun-verb pairs. However, we can discard random pairs by putting a threshold on the co-occurrence frequency (10), noun frequency (5), verb frequency (5)
